---
title: Candle Shrinkage Trick
youtube_id: 4O7_6nvAk08
date: 2014-12-09
tags: [Candles, Tips]
---
If you're making large candles you will experience shrinkage as the wax cools. There's an easy trick to fixing it without making a mess or a blobby bottom.