---
title: Honey Extraction
youtube_id: RtBU14fZHJM
date: 2015-08-20
tags: [Honey, Comb, Interview]
---
One of the criticisms and downsides of not using foundation is the difficulty in extracting the honey without destroying the comb. I decided to see how well my comb holds up in a radial extractor. Will it explode?

I was also interviewed on the Kiwimana Buzz show. I had a great time talking about beekeeping in Portland and how I create my videos. [You can listen to the show here](http://kiwimana.co.nz/filming-the-bees-with-bill-catherall-from-the-beevlog-km075/)

* [More on crush & strain harvesting](https://www.youtube.com/watch?v=CH7uVo42vVk)
* [The t-shirt: "We are all batpeople"](https://www.youtube.com/watch?v=ahQzTLqIAoA)