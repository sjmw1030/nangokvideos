---
title: Checking on Winter Survivors
youtube_id: aJ9m8OPn_oc
date: 2015-02-14
tags: [Winter, Hive, Pollen]
---
Is spring here already? Not quite, but the bees are doing great and bringing in lots of pollen. I had a good winter, with a 64% survivor rate. In this video I take a look at the survivors and deadouts and report on the results.