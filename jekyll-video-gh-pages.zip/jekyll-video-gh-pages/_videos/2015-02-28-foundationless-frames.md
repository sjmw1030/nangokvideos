---
title: Foundationless Frames
youtube_id: VwJjE2g-0tc
date: 2015-02-28
tags: [Combs, Construction, Foundation]
---
In this video I show 2 methods I use to create a comb guide to help the bees build straight comb. I also give the reasons I choose not to use foundation and show what is meant by "bee space."