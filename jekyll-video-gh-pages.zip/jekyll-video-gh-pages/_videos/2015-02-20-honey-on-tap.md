---
title: Honey On Tap?
youtube_id: AF-kkb9jG1A
date: 2015-02-20
tags: [Flow Hive, Honey Bucket]
---
Have you been seeing this advertisement for the Flow Hive all over the internet like I have? I'll give you my thoughts on the product in this video.

Check it out for yourself:

* [Original Flow Hive video](https://www.youtube.com/watch?v=0_pj4cz2VJM)
* [Website](http://www.honeyflow.com/)
* [Here's the patent](http://www.freepatentsonline.com/20140370781.pdf).
