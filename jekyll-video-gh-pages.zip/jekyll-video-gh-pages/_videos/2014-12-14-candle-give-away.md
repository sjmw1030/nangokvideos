---
title: Candle Give-away
youtube_id: WELF-1GvuJM
date: 2014-12-14
tags: [Christmas, Give-away]
---
Thanks to everyone who participated and shared their favorite Christmas/family tradition. I had a great time reading them. I hope you did too. Now it's time to draw names to see who gets a candle...

Didn't win? [You can buy candles in my shop!](http://thebeevlog.com/shop)