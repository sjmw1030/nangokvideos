---
title: What type of bees?
youtube_id: MapUVzHhov8
date: 2015-02-16
tags: [Q&A]
---
Beginner beekeepers can often feel overwhelmed with choices when it comes to buying bees. In this Q&A I attempt to answer the question about the differences between the variety of bees on the market in the US and which ones a beginner should buy.

* [Winterizing beehives with quilt boxes](https://www.youtube.com/watch?v=259kWwVOvmA)
* [Deborah Delaney's presentation](https://www.youtube.com/watch?v=mziimuh0iRc)
* [More information](http://www.bushfarms.com/beesraces.htm)