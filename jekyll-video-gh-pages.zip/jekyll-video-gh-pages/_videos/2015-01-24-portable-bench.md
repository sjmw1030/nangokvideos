---
title: Portable Bench
youtube_id: 3yRHVVwbzHo
date: 2015-01-24
tags: [Bench, Construction]
---
A few years ago, very early in the history of this vlog, I showed my portable bench made from the plans found in the Jan 2012 issue of Bee Culture magazine. I've been using the bench consistently since then, I just never really talked about it again. To make up for that, here's a video showing more about the bench designed by Katharina Davitt.

* [Free downloadable plans](https://drive.google.com/file/d/0B19LtAPiDZi5Y1dGYkNvRXhoWTg/view)
* [Recommended dimensional changes](http://www.thebeevlog.com/2015/01/portable-bench-bee-vlog-jan-24-2015.html)
* [Additional photos](https://www.facebook.com/media/set/?set=a.350254765105307.1073741829.331132277017556&type=3)