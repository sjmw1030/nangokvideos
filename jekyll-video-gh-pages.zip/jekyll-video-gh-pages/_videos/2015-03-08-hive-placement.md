---
title: Hive Placement
youtube_id: 8NkIHP5g_lY
date: 2015-03-08
tags: [Placement, Tips, Climate]
---
Where are you going to put your hives? Do you need sunlight or shade? What about access? Water?