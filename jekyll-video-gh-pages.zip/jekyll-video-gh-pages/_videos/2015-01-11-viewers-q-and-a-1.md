---
title: Viewer Q&A #1
youtube_id: sIjb-H9IJSc
date: 2015-01-11
tags: [Q&A]
---
Got any questions or video suggestions? Comment below and I'll answer your questions in a future video.

Books & websites mentioned in this video:

* [The Complete Idiot's Guide to Beekeeping](http://www.amazon.com/Complete-Idiots-Guide-Beekeeping/dp/1615640118/)
* [The Practical Beekeeper](http://www.amazon.com/Practical-Beekeeper-Beekeeping-Naturally/dp/1614760640/)
* [Inspecting Deadouts](https://www.youtube.com/watch?v=bol-1iCDdDI)