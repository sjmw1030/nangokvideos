---
title: Disneyland Edition
youtube_id: giMGJJ4pqnI
date: 2015-07-25
tags: [VidCon, Disney]
---
Went to VidCon in Anaheim, CA and had a fun time. We also visited Disneyland, because I'm a Disney Freak, and I tried to find as many bee references as I could.

The YouTube creators shown in this video:

* [Michael Aranda](https://www.youtube.com/user/scishow)
* [Chris](https://www.youtube.com/user/BallingersPresent) & [Jessica](https://www.youtube.com/user/jbtvs) Ballinger
* [Felicia Day](https://www.youtube.com/user/geekandsundry)
* [Convos With My 2-Year-Old (Matt, Leila, Coco & Shephard)](https://www.youtube.com/user/ConvosWith2YrOld)
* V Sauce ([Michael Stevens](https://www.youtube.com/user/Vsauce), [Kevin Lieber](https://www.youtube.com/user/Vsauce2), [Jake Roper](https://www.youtube.com/user/Vsauce3))
