---
title: Washboarding
youtube_id: T6NgOjyO0sY
date: 2015-07-18
tags: [Beehavior]
---
Have you ever watched bees do this bizarre and fascinating behavior? What do you think they're doing?